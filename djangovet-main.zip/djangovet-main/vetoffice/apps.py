from django.apps import AppConfig


class VetofficeConfig(AppConfig):
    name = 'vetoffice'
